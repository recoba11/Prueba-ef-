import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { JwtRequestDTO } from '../models/JwtRequestDTO';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable({
  providedIn: 'root',
})
export class Loginservice {
  //npm install @auth0/angular-jwt
  constructor(
    private http: HttpClient,
    @Inject(PLATFORM_ID) private platformId: Object,
  ) {}

  private isBrowser(): boolean {
    return isPlatformBrowser(this.platformId);
  }

  login(request: JwtRequestDTO) {
    return this.http.post('http://localhost:8080/login', request);
  }

  verificar(): boolean {
    if (!this.isBrowser()) {
      return false;
    }

    const token = sessionStorage.getItem('token');
    return token != null;
  }

  showRole(): string | null {
    if (!this.isBrowser()) {
      return null;
    }

    const token = sessionStorage.getItem('token');

    if (!token) {
      return null;
    }
    //npm install @auth0/angular-jwt
    const helper = new JwtHelperService();
    const decodedToken = helper.decodeToken(token);

    return decodedToken.roles;
  }
}
